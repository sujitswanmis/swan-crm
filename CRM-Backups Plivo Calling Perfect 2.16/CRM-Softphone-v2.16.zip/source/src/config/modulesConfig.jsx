import React from 'react';
import { INTEGRATION_PAGE, INTEGRATION_PAGES, CONFIG_MASTER_PAGES } from './integrationsConfig';
import { WHATSAPP_LOG_PAGE, WHATSAPP_LOG_PERMISSION_ITEMS } from './whatsappMessageLogsConfig.js';
import { UserPlus, FileText, Users, Building2, CheckCircle, Archive, Globe, Bot, Shield, PhoneCall, Phone, MessageCircle, Settings2, PieChart, ShieldCheck, Clock, CheckSquare, WifiOff, GitMerge, Navigation } from 'lucide-react';

export const MODULES_CONFIG = [
  // General / Dashboards
  {
    id: 'analytics', path: 'analytics', label: 'Analytics Dashboard', category: 'General',
    icon: <PieChart size={20} />, viewOnly: true,
    subItemsType: 'tabs',
    roleDisplayTabs: [
      { id: 'overview', label: 'Executive Overview' },
      { id: 'scorecard', label: 'Team Scorecard' },
      { id: 'lead-data', label: 'Lead Data' },
      { id: 'delegation', label: 'Delegation Tasks' },
      { id: 'checklist', label: 'Daily Checklists' },
      { id: 'attendance', label: 'Attendance Ops' },
      { id: 'recruiter', label: 'Recruiter Hub' }
    ],
    subItems: [
      { id: 'overview', label: 'Executive Overview' },
      { id: 'scorecard', label: 'Team Scorecard' },
      { id: 'lead-data', label: 'Lead Data' },
      { id: 'delegation', label: 'Delegation Tasks' },
      { id: 'checklist', label: 'Daily Checklists' },
      { id: 'attendance', label: 'Attendance Ops' },
      { id: 'recruiter', label: 'Recruiter Hub' }
    ],
    roleDisplayNote: 'All tabs use Analytics Dashboard access.'
  },

  // AI Chatbot
  { id: 'new_swan_ai', path: 'ai', label: 'AI Assistant Chat', category: 'AI Chatbot', icon: <Bot size={20} />, viewOnly: true },
  { 
    id: 'aiadmin', 
    path: 'aiadmin', 
    label: 'AI Admin & Models', 
    category: 'AI Chatbot', 
    icon: <Bot size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'users', label: 'AI Chatbot Users' },
      { id: 'billing', label: 'API Usage & Billing' },
      { id: 'models', label: 'AI Model Setup' }
    ]
  },
  { id: 'aiknowledgebase', path: 'aiknowledgebase', label: 'Knowledge Base (RAG)', category: 'AI Chatbot', icon: <Bot size={20} /> },

  // Call Center
  { id: 'callcenter', path: 'callcenter', label: 'Telecalling Desk', category: 'Call Center', icon: <PhoneCall size={20} />, viewOnly: true },
  { 
    id: 'calladmin', 
    path: 'calladmin', 
    label: 'Call Admin & SIP', 
    category: 'Call Center', 
    icon: <Phone size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'agents', label: 'Agents & Endpoints' },
      { id: 'endpoints', label: 'SIP Endpoints' },
      { id: 'telephony', label: 'Telephony & Seats' },
      { id: 'calllogs', label: 'Call Logs' },
      { id: 'monitor', label: 'Live Monitor' },
      { id: 'settings', label: 'Routing & Rules' }
    ]
  },
  { 
    id: 'aicallcenter', 
    path: 'aicallcenter', 
    label: 'AI Voice Call Center', 
    category: 'Call Center', 
    icon: <Bot size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'dashboard', label: 'Dashboard' },
      { id: 'campaigns', label: 'Campaigns' },
      { id: 'settings', label: 'Incoming Settings' }
    ]
  },
  { 
    id: 'attendance', 
    path: 'attendance', 
    label: 'Smart Attendance', 
    category: 'General', 
    icon: <Clock size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'my_attendance', label: 'Daily Punch Station' },
      { id: 'monthly_logs', label: 'Monthly Attendance Log' },
      { id: 'regularization', label: 'Missing Punch / Regularize' },
      { id: 'my_leaves', label: 'My Leaves' },
      { id: 'hod_approvals', label: 'HOD Approvals' },
      { id: 'team_report', label: 'Team Attendance Report' },
      { id: 'live_tracking', label: 'Live Field Tracking & Radar' },
      { id: 'shift_rules', label: 'Shift Rules' },
      { id: 'leave_policy', label: 'Company Leave Policy' },
      { id: 'geofencing', label: 'Office Geofencing Policy' }
    ]
  },
  {
    id: 'field_force',
    path: 'field_force',
    label: 'Field Force & Form Studio',
    category: 'General',
    icon: <Navigation size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'mobile_dashboard', label: '📱 Field Executive App' },
      { id: 'task_manager', label: '📋 Field Tasks Manager' },
      { id: 'form_studio', label: '🎨 Custom Form Studio' },
      { id: 'live_radar', label: '🛰️ Live GPS & Playback' }
    ]
  },
  {
    id: 'checklist',
    path: 'checklist',
    label: 'Smart Checklist',
    category: 'General',
    icon: <CheckSquare size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'dashboard', label: '📊 Checklist Dashboard' },
      { id: 'my_checklists', label: '📋 My Checklists' },
      { id: 'templates', label: '📑 Templates Master' },
      { id: 'compliance', label: '📊 Compliance & Audit' }
    ]
  },
  {
    id: 'delegation',
    path: 'delegation',
    label: 'Delegation Tasks',
    category: 'General',
    icon: <Users size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'dashboard', label: '📊 Delegation Dashboard' },
      { id: 'to_me', label: '📥 Tasks To Me' },
      { id: 'by_me', label: '📤 Tasks By Me' },
      { id: 'all', label: '👥 Team Task Board' }
    ]
  },

  // Sales
  { id: 'registration', path: 'registration', label: 'New Lead Registration', category: 'Sales', icon: <UserPlus size={20} /> },
  { id: 'report', path: 'report', label: 'Lead Registered Report', category: 'Sales', icon: <FileText size={20} /> },
  { 
    id: 'leads', 
    path: 'leads', 
    label: 'Lead Data', 
    category: 'Sales', 
    icon: <Users size={20} />,
    subItemsType: 'leads_stages',
    roleDisplayTabs: [{ id: 'all_leads', label: 'All Leads' }],
    roleDisplayNote: 'All Leads uses the selected lead stages.',
    subItems: [
      { id: 'lead_dashboard', label: '📊 Lead Dashboard' },
      { id: 'hourly_work', label: '⏰ Hourly Work' },
      { id: 'all_leads', label: '📋 All Leads' },
      { id: '01 - New Stage', label: '01 - New Stage' },
      { id: '02 - Contact Stage', label: '02 - Contact Stage' },
      { id: '03 - Qualification Stage', label: '03 - Qualification Stage' },
      { id: '04 - Follow Up Stage', label: '04 - Follow Up Stage' },
      { id: '05 - Sales Process Stage', label: '05 - Sales Process Stage' },
      { id: '06 - Conversion Stage', label: '06 - Conversion Stage' },
      { id: '07 - Final Stage', label: '07 - Final Stage' },
      { id: '08 - Transfer to Party', label: '08 - Transfer to Party' }
    ]
  },
  { 
    id: 'party', 
    path: 'party', 
    label: 'Party Master', 
    category: 'Sales', 
    icon: <Building2 size={20} />,
    subItemsType: 'tabs',
    roleDisplayTabs: [
      { id: 'dashboard', label: 'Party Master Dashboard' },
      { id: 'all_party_stage', label: 'All Party Stage' }
    ],
    roleDisplayNote: 'Party Master Dashboard and All Party Stage require manager access or can be explicitly assigned.',
    subItems: [
      { id: 'dashboard', label: '📊 Party Master Dashboard' },
      { id: 'all_party_stage', label: '📋 All Party Stage' },
      { id: 's00', label: 'S00 Transfered to Party Master' },
      { id: 's01', label: 'S01 Party Master Creation' },
      { id: 's02', label: 'S02 Distributor Registration' },
      { id: 's03', label: 'S03 Dealer Registration' },
      { id: 's04', label: 'S04 Sub-Dealer Registration' },
      { id: 's05', label: 'S05 Commercial Security Details' },
      { id: 's06', label: 'S06 Product Auth & Territory' },
      { id: 's07', label: 'S07 Sales Team Assignment' },
      { id: 's08', label: 'S08 Partner Activation' },
      { id: 'report', label: '📑 Party Master Report' },
      { id: 'hierarchy_tree', label: '🌳 Channel Hierarchy Tree' },
      { id: 'end_customers', label: '🚜 End Customer Master' }
    ]
  },
  { 
    id: 'channel_ops', 
    path: 'channel-operations', 
    label: 'Daily Order Follow-up', 
    category: 'Sales', 
    icon: <PhoneCall size={20} />,
    subItemsType: 'tabs',
    roleDisplayTabs: [
      { id: 'order_pipeline', label: 'Order to Delivery Pipeline' },
      { id: 'all_orders', label: 'Pipeline: All Orders' }
    ],
    roleDisplayNote: 'Pipeline stages can be assigned individually or inherited from Order to Delivery Pipeline / All Orders.',
    subItems: [
      { id: 'frequency_rules', label: '⚙️ Order Frequency Master' },
      { id: 'order_followup', label: '📞 Order Desk Calling' },
      { id: 'order_pipeline', label: '🚚 Order to Delivery Pipeline' },
      { id: 'all_orders', label: '📦 Pipeline: All Orders' },
      { id: 's01', label: 'S01 - Order Confirmation' },
      { id: 's02', label: 'S02 - PI Generation' },
      { id: 's03', label: 'S03 - PI Shared' },
      { id: 's04', label: 'S04 - Request Advance Payment' },
      { id: 's05', label: 'S05 - Receive Advance Payment' },
      { id: 's06', label: 'S06 - Check Stock & Production' },
      { id: 's07', label: 'S07 - Product Partial & Full Status' },
      { id: 's08', label: 'S08 - Quality Check (PDI)' },
      { id: 's09', label: 'S09 - Request 70% Balance' },
      { id: 's10', label: 'S10 - Receive 70% Balance' },
      { id: 's11', label: 'S11 - Ready for Dispatch' },
      { id: 's12', label: 'S12 - Dispatch Material' },
      { id: 's13', label: 'S13 - Material Delivered (POD)' },
      { id: 'order_feedback', label: '⭐ Post-Order Feedback' },
      { id: 'monthly_feedback', label: '📅 Monthly Health Checks' },
      { id: 'complaints', label: '⚠️ Complaint Management' },
      { id: 'c01', label: 'C01 - Ticket Logged & Triaged' },
      { id: 'c02', label: 'C02 - Internal Dept RCA' },
      { id: 'c03', label: 'C03 - Service Engineer Deputed' },
      { id: 'c04', label: 'C04 - On-Site Job Card' },
      { id: 'c05', label: 'C05 - Customer OTP Verification' },
      { id: 'c06', label: 'C06 - Quality Audit & Closed' },
      { id: 'end_customers', label: '🚜 End Customer Master' }
    ]
  },
  { 
    id: 'location_master', 
    path: 'location_master', 
    label: 'Location Master', 
    category: 'Sales', 
    icon: <Globe size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'explorer', label: '1. Explorer' },
      { id: 'states', label: '2. States / UTs' },
      { id: 'districts', label: '3. Districts' },
      { id: 'subdistricts', label: '4. Tehsil / Sub-District' },
      { id: 'blocks', label: '5. Development Blocks' },
      { id: 'settlements', label: '6. Cities / Towns / Villages' },
      { id: 'post_offices', label: '7. PIN / Post Offices' },
      { id: 'aliases', label: '8. Aliases' },
      { id: 'import', label: '9. Import' },
      { id: 'requests', label: '10. Location Requests' },
      { id: 'history', label: '11. Change History' }
    ]
  },

  // Purchase
  { id: 'mrp', path: 'mrp', label: 'MRP System', category: 'Purchase', icon: <Archive size={20} /> },
  { id: 'mrp_against', path: 'mrp_against', label: 'MRP Against', category: 'Purchase', icon: <FileText size={20} /> },

  // Human Resource
  { 
    id: 'recruiter', 
    path: 'recruiter', 
    label: 'Recruiter Dashboard', 
    category: 'Human Resource', 
    icon: <Users size={20} />,
    subItemsType: 'recruiter_stages',
    roleDisplayTabs: [
      { id: 'dashboard', label: 'Recruiter Dashboard' },
      { id: 'all_stages', label: 'Recruiter All Stage' }
    ],
    roleDisplayNote: 'Dashboard and All Stage require manager access or can be explicitly assigned.',
    subItems: [
      { id: 'dashboard', label: '📊 Recruiter Dashboard' },
      { id: 'all_stages', label: '🔍 Recruiter All Stage' },
      { id: 'S00', label: 'S00 — Requirements Received' },
      { id: 'S01', label: 'S01 — JDs Prepared & Posted' },
      { id: 'S02', label: 'S02 — Resume Filtered' },
      { id: 'S03', label: 'S03 — Interview Executed' },
      { id: 'S04', label: 'S04 — Test Results' },
      { id: 'S05', label: 'S05 — ED Approval' },
      { id: 'S06', label: 'S06 — Salary Negotiation' },
      { id: 'S07', label: 'S07 — Shortlisted' },
      { id: 'S08', label: 'S08 — LOI Released' },
      { id: 'S09', label: 'S09 — Joined' }
    ]
  },
  { id: 'joining', path: 'joining', label: 'Joining Process', category: 'Human Resource', icon: <CheckCircle size={20} /> },

  // User Management
  { 
    id: 'user_management_new', 
    path: 'user_management_new', 
    label: 'User Management', 
    category: 'User Management', 
    icon: <Users size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'user_manage', label: 'User Manage' },
      { id: 'roles', label: 'Roles & Permissions' },
      { id: 'hierarchy', label: 'Org Hierarchy' },
      { id: 'sessions', label: 'Active Sessions' },
      { id: 'audit', label: 'Audit Logs' }
    ]
  },

  // System
  { id: 'team', path: 'team', label: 'Team Management', category: 'System', icon: <Shield size={20} /> },
  { 
    id: 'workplace', 
    path: 'workflow', 
    label: 'Workflow Builder', 
    category: 'Workflow Builder', 
    icon: <GitMerge size={20} />,
    roleAssignable: false,
    subItemsType: 'tabs',
    subItems: [
      { id: 'active', label: 'Active Workflows' },
      { id: 'tracker', label: 'Live Working Tracker' },
      { id: 'trash', label: 'Trash Bin' }
    ]
  },
  { id: 'public_users', path: 'public_users', label: 'Public User Management', category: 'Master Admin', icon: <Users size={20} />, roleAssignable: false, masterAdminOnly: true, roleRestrictionLabel: 'Master Admin only' },

  // Communication Center
  { 
    id: 'whatsapp_official', 
    path: 'whatsapp_official', 
    label: 'WhatsApp Official', 
    category: 'Communication Center', 
    icon: <MessageCircle size={20} />,
    subItemsType: 'tabs',
    roleDisplayTabs: [
      { id: 'catalog', label: 'Master BSP Catalog (20+)' },
      { id: 'allocations', label: 'Client Allocation Matrix' }
    ],
    roleDisplayNote: 'Catalog and Allocation Matrix are Master Admin only.',
    subItemGroups: [WHATSAPP_LOG_PAGE],
    subItems: [
      { id: 'templates', label: 'Templates Library' },
      { id: 'automations', label: 'Stage Automations' },
      ...WHATSAPP_LOG_PERMISSION_ITEMS,
      { id: 'settings', label: 'API Credentials & Setup' }
    ]
  },
  { 
    id: 'whatsapp_unofficial', 
    path: 'whatsapp_unofficial', 
    label: 'WhatsApp UnOfficial', 
    category: 'Communication Center', 
    icon: <MessageCircle size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'dashboard', label: 'Dashboard' },
      { id: 'templates', label: 'Message Templates' },
      { id: 'live_chat', label: 'Live Chat Inbox' },
      { id: 'instances', label: 'Instance Management' },
      { id: 'settings', label: 'API & BSP Setup' },
      { id: 'auth', label: 'User Authorization' },
      { id: 'test', label: 'Test Message' },
      { id: 'logs', label: 'Message Logs' }
    ]
  },
  { id: 'sms_config', path: 'sms_config', label: 'SMS Configuration', category: 'Communication Center', icon: <MessageCircle size={20} />, viewOnly: true },
  { id: 'rcs_config', path: 'rcs_config', label: 'RCS Configuration', category: 'Communication Center', icon: <MessageCircle size={20} />, viewOnly: true },
  {
    id: 'email_config', path: 'email_config', label: 'Email Configuration', category: 'Communication Center',
    icon: <MessageCircle size={20} />,
    subItemsType: 'tabs',
    subItems: [
      { id: 'smtp', label: '⚙️ SMTP Server Settings' },
      { id: 'templates', label: '📝 Email Templates' },
      { id: 'automations', label: '⚡ Stage Automations' },
      { id: 'test', label: '🚀 Live Email Test' },
      { id: 'logs', label: '📜 Sent History' }
    ],
    roleDisplayTabs: [
      { id: 'smtp', label: 'SMTP Server Settings' },
      { id: 'templates', label: 'Email Templates' },
      { id: 'automations', label: 'Stage Automations' },
      { id: 'test', label: 'Live Email Test' },
      { id: 'logs', label: 'Sent History' }
    ],
    roleDisplayNote: 'All tabs use Email Configuration access.'
  },
  {
    id: 'config_master', path: 'config-master', label: 'Config Master', category: 'Master Admin',
    icon: <ShieldCheck size={20} />, roleAssignable:false, masterAdminOnly:true,
    roleRestrictionLabel:'Master Admin only', subItemsType:'tabs', subItems:CONFIG_MASTER_PAGES
  },
  { 
    id: 'admin_message_config',
    path: 'admin_message_config', 
    label: 'Admin Message Config', 
    category: 'Master Admin', 
    icon: <ShieldCheck size={20} />,
    roleAssignable: false,
    subItemsType: 'tabs',
    subItems: [
      { id: 'wa_official', label: 'WhatsApp Official' },
      { id: 'wa_unofficial', label: 'WhatsApp Unofficial' },
      { id: 'sms', label: 'SMS Configuration' },
      { id: 'rcs', label: 'RCS Configuration' },
      { id: 'email', label: 'Email Setup' }
    ]
  },
  { 
    id: 'offline_rule', 
    path: 'offline_rule', 
    label: 'Offline Rule', 
    category: 'Master Admin', 
    icon: <WifiOff size={20} />,
    roleAssignable: false,
    masterAdminOnly: true,
    roleRestrictionLabel: 'Master Admin only' 
  },
  { 
    id: 'settings', 
    path: 'settings', 
    label: 'Settings', 
    category: 'Settings', 
    icon: <Settings2 size={20} />,
    subItemsType: 'tabs',
    subItemGroups: [INTEGRATION_PAGE],
    subItems: [
      { id: 'business', label: 'Business Profile & Branches' },
      { id: 'products', label: 'Product List & Branches' },
      { id: 'order_pipeline', label: 'Order to Delivery Config' },
      { id: 'complaints_config', label: 'Complaint Management Config' },
      { id: 'crm', label: 'CRM & Lead Config' },
      { id: 'notifications', label: 'Notifications & Alerts' },
      { id: 'departments', label: 'Manage Departments' },
      { id: 'targets', label: 'Targets & Performance' },
      { id: 'sessions', label: 'Work & Session Rules' },
      { id: 'holidays', label: 'Holidays Calendar Config' },
      { id: 'data', label: 'Data Management' },
      { id: 'media', label: 'File & Media Settings' },
      ...INTEGRATION_PAGES
    ]
  }
];

